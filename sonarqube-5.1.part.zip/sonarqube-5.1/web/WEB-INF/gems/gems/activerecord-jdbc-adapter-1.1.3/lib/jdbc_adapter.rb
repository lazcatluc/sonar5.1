warn "DEPRECATED: require 'arjdbc' instead of 'jdbc_adapter'."
require 'arjdbc'
