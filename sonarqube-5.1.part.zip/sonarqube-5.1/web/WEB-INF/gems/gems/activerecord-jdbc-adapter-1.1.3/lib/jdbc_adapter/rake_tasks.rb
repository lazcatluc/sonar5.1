warn "DEPRECATED: require 'arjdbc/rake_tasks' instead of 'jdbc_adapter/rake_tasks'."
require 'arjdbc/jdbc/rake_tasks'

