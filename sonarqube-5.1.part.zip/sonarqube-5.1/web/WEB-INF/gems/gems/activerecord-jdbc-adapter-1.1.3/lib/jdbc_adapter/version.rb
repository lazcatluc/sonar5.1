warn "DEPRECATED: require 'arjdbc/version' instead of 'jdbc_adapter/version'."
require 'arjdbc/version'

