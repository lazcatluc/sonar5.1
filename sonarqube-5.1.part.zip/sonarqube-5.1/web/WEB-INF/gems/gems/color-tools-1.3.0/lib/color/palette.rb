#--
# Colour management with Ruby.
#
# Copyright 2005 Austin Ziegler
#   http://rubyforge.org/ruby-pdf/
#
#   Licensed under a MIT-style licence.
#
# $Id: palette.rb,v 1.2 2005/08/05 23:07:20 austin Exp $
#++

require 'color'

module Color::Palette
end
