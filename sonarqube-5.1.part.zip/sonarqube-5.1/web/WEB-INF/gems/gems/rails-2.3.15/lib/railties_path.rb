RAILTIES_PATH = File.join(File.dirname(__FILE__), '..')
